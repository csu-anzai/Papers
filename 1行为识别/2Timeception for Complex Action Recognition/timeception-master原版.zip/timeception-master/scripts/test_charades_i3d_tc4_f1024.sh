#!/usr/bin/env bash

python ../experiments/test.py --config_file charades_i3d_tc4_f1024.yaml