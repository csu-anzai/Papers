# C3D for pytorch

This is a pytorch porting of the network presented in the paper [Learning Spatiotemporal Features with 3D Convolutional Networks](http://www.cv-foundation.org/openaccess/content_iccv_2015/papers/Tran_Learning_Spatiotemporal_Features_ICCV_2015_paper.pdf)

---
### How to use:
* Download the pretrained weights (Sports1M) from [here](http://imagelab.ing.unimore.it/files/c3d_pytorch/c3d.pickle).
* Run the predict script.

**disclaimer**: Performances tested only qualitatively! No warranty!
